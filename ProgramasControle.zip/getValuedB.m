function valordB = getValuedB(valor)
    valordB = 20*log10(valor);
end