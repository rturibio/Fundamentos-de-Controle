function valor = getValue(valordB)
    valor = 10^(valordB/20);
end