close all

syms('K')
rhcnew([1 15 54 K])