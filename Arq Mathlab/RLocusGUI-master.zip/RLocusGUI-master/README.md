I have stopped working on RLocuysGui and have developed a similar tool in JavaScript to make it more accessible (https://lpsa.swarthmore.edu/Root_Locus/RLDraw.html). While MATLAB is extremely powerful, it is also very expensive.

# RLocusGUI
Tool to learn how to draw root locus diagrams.

****MATLAB version below this line****
This is a MATLAB tool that describes the process of creating a root locus diagram by hand for a user supplied transfer function.  Instead of simply creating the locus, it describes how to apply rules to sketch the locus by hand.

Read more at: http://lpsa.swarthmore.edu/Root_Locus/RLocusGui.html
